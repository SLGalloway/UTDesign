//
//  TransmissionData.h
//  Location2
//
//  Created by Tommy Brown on 2/10/16.
//  Copyright (c) 2016 guang zhou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@interface TransmissionData : NSObject

@property (nonatomic) int power;
@property (nonatomic) int turn;
@property (nonatomic) bool enable;
@property (nonatomic) bool reverse;
@property (nonatomic) float heading;
@property (nonatomic) float latitude;
@property (nonatomic) float longitude;
@property (nonatomic, strong) NSMutableArray *waypointArray;
@property (nonatomic) bool newWaypoint;

- (id) initWithPower:(int) power turn:(int) turn enable:(bool) enable;

- (NSDictionary *) toDictionary;

@end
