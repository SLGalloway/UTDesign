//
//  TransmissionData.m
//  Location2
//
//  Created by Tommy Brown on 2/10/16.
//  Copyright (c) 2016 guang zhou. All rights reserved.
//

#import "TransmissionData.h"
#import "Coord.h"

@implementation TransmissionData

- (id) init{
    return [self initWithPower:0 turn:0 enable:NO];
}

- (id) initWithPower:(int) power turn:(int) turn enable:(bool) enable{
    self = [super init];
    if(self){
        self.waypointArray = [[NSMutableArray alloc] init];
        _power = power;
        _turn = turn;
        _enable = enable;
    }
    return self;
}

- (NSDictionary *) toDictionary{
    NSMutableDictionary *superDictionary = [[NSMutableDictionary alloc] init];
    
    superDictionary[@"power"] = [NSNumber numberWithInteger:self.power];
    superDictionary[@"turn"] = [NSNumber numberWithInteger:self.turn];
    superDictionary[@"enable"] = [NSNumber numberWithInteger:self.enable];
    superDictionary[@"reverse"] = [NSNumber numberWithInteger:self.reverse];
    superDictionary[@"latitude"] = [NSNumber numberWithFloat:self.latitude];
    superDictionary[@"longitude"] = [NSNumber numberWithFloat:self.longitude];
    superDictionary[@"heading"] = [NSNumber numberWithFloat:self.heading];
    superDictionary[@"gpsNav"] = [NSNumber numberWithInteger:self.newWaypoint];
    
    if(self.newWaypoint){
        NSMutableArray *waypoints = [[NSMutableArray alloc] init];
        for(Coord *coord in self.waypointArray){
            NSMutableArray *coordArray = [[NSMutableArray alloc] init];
            [coordArray addObject:[NSNumber numberWithFloat:coord.latitude]];
            [coordArray addObject:[NSNumber numberWithFloat:coord.longitude]];
            [waypoints addObject:coordArray];
        }
        superDictionary[@"waypoints"] = waypoints;
        
        self.newWaypoint = NO;
    }
    
    return superDictionary;
}

@end
