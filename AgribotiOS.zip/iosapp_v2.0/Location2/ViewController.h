//
//  ViewController.h
//  Location2
//
//  Created by guang zhou on 5/19/15.
//  Copyright (c) 2015 guang zhou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
@interface ViewController : UIViewController <NSStreamDelegate, CLLocationManagerDelegate>
{
    NSInputStream *inputStream;
    NSOutputStream *outputStream;
}
@property (weak, nonatomic) IBOutlet UILabel *longitude;
@property (weak, nonatomic) IBOutlet UILabel *latitude;
@property (weak, nonatomic) IBOutlet UILabel *trueHeading;
@property (weak, nonatomic) IBOutlet UILabel *r;
@property (weak, nonatomic) IBOutlet UILabel *theta;
@property (weak, nonatomic) IBOutlet UILabel *ouput;

@property (weak, nonatomic) IBOutlet MKMapView *mapView;

@property (weak, nonatomic) IBOutlet UITextField *input;

- (IBAction)Forward:(id)sender;
- (IBAction)TurnL:(id)sender;
- (IBAction)TurnR:(id)sender;
- (IBAction)Reverse:(id)sender;
- (IBAction)Stop:(id)sender;
- (IBAction)sendCmd:(id)sender;

- (IBAction)setMap:(id)sender;
- (IBAction)setCar:(id)sender;
@end

