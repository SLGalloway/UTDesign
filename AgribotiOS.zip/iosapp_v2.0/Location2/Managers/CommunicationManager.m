//
//  CommunicationManager.m
//  Location2
//
//  Created by Tommy Brown on 2/5/16.
//  Copyright (c) 2016 guang zhou. All rights reserved.
//

#import "CommunicationManager.h"
#import <CoreLocation/CoreLocation.h>

#define BOARD_IP_ADDRESS @"192.168.1.1"
#define BOARD_PORT 80
#define TRANSMISSION_RATE 0.2

@interface CommunicationManager(){
    NSInputStream *inputStream;
    NSOutputStream *outputStream;
    NSTimer *timer;
    NSTimer *locationUpdateTimer;
    float latitude;
    float longitude;
}
@end

static CommunicationManager *instance = nil;

@implementation CommunicationManager

+ (CommunicationManager *) getSharedInstance{
    if(!instance){
        instance = [[self alloc] init];
    }
    
    return instance;
}

- (id) init{
    self = [super init];
    if(self){
        
        self.transmissionData = [[TransmissionData alloc] init];
        
        self.locationManager = [[CLLocationManager alloc] init];
        self.locationManager.delegate = self;
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        self.locationManager.distanceFilter = 1;
        [self.locationManager startMonitoringSignificantLocationChanges];
        [self.locationManager startUpdatingHeading];
        [self.locationManager requestWhenInUseAuthorization];
        
        CFReadStreamRef readStream;
        CFWriteStreamRef writeStream;
        CFStreamCreatePairWithSocketToHost(NULL, (CFStringRef) BOARD_IP_ADDRESS, BOARD_PORT, &readStream, &writeStream);
        
        inputStream = (__bridge  NSInputStream *)readStream;
        outputStream = (__bridge  NSOutputStream *)writeStream;
        [inputStream setDelegate:self];
        [outputStream setDelegate:self];
        [inputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        [outputStream scheduleInRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
        [inputStream open];
        [outputStream open];
        
        locationUpdateTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(locationTimerFired) userInfo:nil repeats:YES];
        
    }
    return self;
}

- (void) beginTransmissions{
    timer = [NSTimer scheduledTimerWithTimeInterval:TRANSMISSION_RATE target:self selector:@selector(transmissionTimerFired) userInfo:nil repeats:YES];
}

- (void) stopTransmissions{
    [timer invalidate];
    timer = nil;
}

- (void) sendToRobot:(NSString *)command{
    //NSLog(@"Sending %@ to robot.", command);
    
    if(inputStream.streamStatus == NSStreamStatusOpen){
        NSString *response = [command stringByAppendingString:@"\n"];
        NSData *data = [[NSData alloc] initWithData:[response dataUsingEncoding:NSASCIIStringEncoding]];
        [outputStream write:[data bytes] maxLength:[data length]];
    }else{
        //NSLog(@"Stream not open");
    }
}

- (void) sendDictionaryToRobot:(NSDictionary *)dictionary{
    if(inputStream.streamStatus == NSStreamStatusOpen){
        
        NSError *error;
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dictionary options:0 error:&error];
        NSLog(@"would send: %@", [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding]);
        [outputStream write:[jsonData bytes] maxLength:[jsonData length]];
    }else{
        //NSLog(@"Stream not open");
    }
}

+ (NSString *) encodeVariablesForRobot:(int) power turn:(int) turn enable:(BOOL) enable scan:(BOOL) scan{
    return [[NSString stringWithFormat:@"%4d,%4d,%d,%d", power, turn, enable, scan] stringByReplacingOccurrencesOfString:@" " withString:@"0"];
}

#pragma mark - NSStreamDelegate

- (void)stream:(NSStream *)theStream handleEvent:(NSStreamEvent)streamEvent{
    switch(streamEvent){
        case NSStreamEventOpenCompleted:
            NSLog(@"Stream opened");
            break;
        case NSStreamEventHasBytesAvailable:
            NSLog(@"Stream has bytes avaiable");
            // Read from inputStream
            break;
        case NSStreamEventErrorOccurred:
            NSLog(@"Can not connect to the host!: %@", [theStream streamError]);
            break;
        case NSStreamEventEndEncountered:
            NSLog(@"Stream closed");
            break;
        default:
            //NSLog(@"Unknown event");
            break;
    }
}

#pragma mark - Actions

- (void) transmissionTimerFired{
    
    NSDictionary *dictionary = [self.transmissionData toDictionary];
    
    [self sendDictionaryToRobot:dictionary];
}

- (void) locationTimerFired{
    self.transmissionData.latitude = self.mapViewShit.mapView.userLocation.coordinate.latitude;
    self.transmissionData.longitude = self.mapViewShit.mapView.userLocation.coordinate.longitude;
    self.transmissionData.heading = self.locationManager.heading.trueHeading;
    [self.mapViewShit.mapView setRegion:(MKCoordinateRegionMake(self.mapViewShit.mapView.userLocation.coordinate, MKCoordinateSpanMake(0.001, 0.001))) animated:NO];
}


@end
