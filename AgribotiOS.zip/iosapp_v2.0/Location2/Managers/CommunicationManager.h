//
//  CommunicationManager.h
//  Location2
//
//  Created by Tommy Brown on 2/5/16.
//  Copyright (c) 2016 guang zhou. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TransmissionData.h"
#import <CoreLocation/CoreLocation.h>
#import "MapViewController.h"

@interface CommunicationManager : NSObject <NSStreamDelegate, CLLocationManagerDelegate>

@property (strong, nonatomic) TransmissionData *transmissionData;
@property (strong, nonatomic) CLLocationManager *locationManager;
@property (weak) MapViewController *mapViewShit;

+ (CommunicationManager *) getSharedInstance;
+ (NSString *) encodeVariablesForRobot:(int) power turn:(int) turn enable:(BOOL) enable scan:(BOOL) scan;

- (void) beginTransmissions;
- (void) stopTransmissions;
- (void) sendToRobot:(NSString *) command;

@end
