//
//  SettingsViewController.m
//  Location2
//
//  Created by Tommy Brown on 2/4/16.
//  Copyright (c) 2016 guang zhou. All rights reserved.
//

#import "SettingsViewController.h"
#import "CommunicationManager.h"

@interface SettingsViewController (){
    CommunicationManager *communicationManager;
}
@end

@implementation SettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    communicationManager = [CommunicationManager getSharedInstance];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStyleDone target:self action:@selector(backButtonPressed:)];
}

#pragma mark - Actions

- (IBAction) backButtonPressed:(id)sender{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction) sendCommandButtonPressed:(id)sender{
    NSString *command = self.customCommandTextField.text;
    if(command != nil && command.length > 0){
        NSLog(@"Sending to robot: %@", command);
        //[communicationManager sendToRobot:command];
    }
}

@end
