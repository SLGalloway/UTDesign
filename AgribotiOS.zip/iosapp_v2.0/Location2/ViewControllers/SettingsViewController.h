//
//  SettingsViewController.h
//  Location2
//
//  Created by Tommy Brown on 2/4/16.
//  Copyright (c) 2016 guang zhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsViewController : UIViewController

@property (nonatomic, weak) IBOutlet UITextField *customCommandTextField;
@property (nonatomic, weak) IBOutlet UIButton *sendCommandbutton;

- (IBAction) sendCommandButtonPressed:(id)sender;

@end
