//
//  MapViewController.h
//  Location2
//
//  Created by Tommy Brown on 2/4/16.
//  Copyright (c) 2016 guang zhou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface MapViewController : UIViewController

@property (weak, nonatomic) IBOutlet MKMapView *mapView;

@property (weak, nonatomic) IBOutlet UISlider *verticalSlider;
@property (weak, nonatomic) IBOutlet UISlider *horizontalSlider;
@property (weak, nonatomic) IBOutlet UISwitch *reverseSwitch;

@property (strong, nonatomic) UISegmentedControl *enableControl;

- (IBAction) verticalSliderChanged:(id)sender;
- (IBAction) horizontalSliderChanged:(id)sender;



@end
