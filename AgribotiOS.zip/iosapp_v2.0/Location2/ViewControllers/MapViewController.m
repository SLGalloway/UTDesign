//
//  MapViewController.m
//  Location2
//
//  Created by Tommy Brown on 2/4/16.
//  Copyright (c) 2016 guang zhou. All rights reserved.
//

#import "MapViewController.h"
#import "SettingsViewController.h"
#import "CommunicationManager.h"
#import "TransmissionData.h"
#import "Coord.h"

#define JOYSTICK_MAX_VALUE 100
#define JOYSTICK_MIN_VALUE -100
#define JOYSTICK_CENTER 0.0

#define ENABLED_INDEX 0
#define DISABLED_INDEX 1

@interface MapViewController (){
    CommunicationManager *communicationManager;
    UITapGestureRecognizer *tapRecognizer;
}
@end

@implementation MapViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.enableControl = [[UISegmentedControl alloc] initWithItems:@[@"Enable", @"Disable"]];
    [self.enableControl addTarget:self action:@selector(enableStateChanged:) forControlEvents:UIControlEventValueChanged];
    [self.enableControl setSelectedSegmentIndex:DISABLED_INDEX];
    
    communicationManager = [CommunicationManager getSharedInstance];
    communicationManager.mapViewShit = self;
    [communicationManager beginTransmissions];
    
    [self.reverseSwitch addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];
    [self.reverseSwitch setOn:NO];
    
    tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(longpressToGetLocation:)];
    
    self.navigationItem.titleView = self.enableControl;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"gear"] style:UIBarButtonItemStylePlain target:self action:@selector(settingsButtonPressed:)];
    [self disableDriveControl];
    
    self.mapView.showsUserLocation = YES;
    [self.mapView setZoomEnabled:YES];
    [self.mapView setScrollEnabled:YES];
    [self.mapView addGestureRecognizer:tapRecognizer];
    self.mapView.showsUserLocation = YES;
    self.mapView.userTrackingMode = YES;
    [self.mapView setCenterCoordinate:self.mapView.userLocation.location.coordinate animated:YES];
    
    self.verticalSlider.transform = CGAffineTransformRotate(self.verticalSlider.transform,270.0 / 180 * M_PI);
    
    [self.verticalSlider setMaximumValue:JOYSTICK_MAX_VALUE];
    [self.verticalSlider setMinimumValue:JOYSTICK_MIN_VALUE];
    [self.horizontalSlider setMaximumValue:JOYSTICK_MAX_VALUE];
    [self.horizontalSlider setMinimumValue:JOYSTICK_MIN_VALUE];
    
    [self.verticalSlider setValue:JOYSTICK_CENTER];
    [self.horizontalSlider setValue:JOYSTICK_CENTER];
    
    [self.verticalSlider addTarget:self action:@selector(verticalSliderReleased:) forControlEvents:UIControlEventTouchUpOutside];
    [self.verticalSlider addTarget:self action:@selector(verticalSliderReleased:) forControlEvents:UIControlEventTouchUpInside];
    [self.horizontalSlider addTarget:self action:@selector(horizontalSliderReleased:) forControlEvents:UIControlEventTouchUpOutside];
    [self.horizontalSlider addTarget:self action:@selector(horizontalSliderReleased:) forControlEvents:UIControlEventTouchUpInside];
    
}

- (void) disableDriveControl{
    [self.verticalSlider setEnabled:NO];
    [self.horizontalSlider setEnabled:NO];
}

- (void) enableDriveControl{
    [self.verticalSlider setEnabled:YES];
    [self.horizontalSlider setEnabled:YES];
}

#pragma mark - Actions

- (IBAction) settingsButtonPressed:(id)sender{
    NSLog(@"Settings button pressed");
    
    SettingsViewController *settingsVC = [[SettingsViewController alloc] init];
    UINavigationController *settingsNav = [[UINavigationController alloc] initWithRootViewController:settingsVC];
    
    [self presentViewController:settingsNav animated:YES completion:nil];
}

- (IBAction) sliderChanged:(id)sender{
    NSLog(@"slider changed: %d", self.reverseSwitch.on);
    communicationManager.transmissionData.reverse = self.reverseSwitch.on;
}

- (IBAction) verticalSliderChanged:(id)sender{
    [communicationManager.transmissionData setPower:self.verticalSlider.value];
}

- (IBAction) horizontalSliderChanged:(id)sender{
    [communicationManager.transmissionData setTurn:self.horizontalSlider.value];
}

- (IBAction) verticalSliderReleased:(id)sender{
    [self.verticalSlider setValue:JOYSTICK_CENTER animated:YES];
    [communicationManager.transmissionData setPower:self.verticalSlider.value];
}

- (IBAction) horizontalSliderReleased:(id)sender{
    [self.horizontalSlider setValue:JOYSTICK_CENTER animated:YES];
    [communicationManager.transmissionData setTurn:self.horizontalSlider.value];
}

- (IBAction) enableStateChanged:(id)sender{
    switch(self.enableControl.selectedSegmentIndex){
        case ENABLED_INDEX:
            [self enableDriveControl];
            break;
        case DISABLED_INDEX:
            [self disableDriveControl];
            break;
    }
    [communicationManager.transmissionData setEnable:!self.enableControl.selectedSegmentIndex];
}

- (void)longpressToGetLocation:(UIGestureRecognizer *)gestureRecognizer
{
    CGPoint touchPoint = [gestureRecognizer locationInView:self.mapView];
    CLLocationCoordinate2D location = [self.mapView convertPoint:touchPoint toCoordinateFromView:self.mapView];
    
    Coord *coord = [[Coord alloc] init];
    coord.latitude = location.latitude;
    coord.longitude = location.longitude;
    
    [communicationManager.transmissionData.waypointArray addObject:coord];
    communicationManager.transmissionData.newWaypoint = YES;
    
    NSLog(@"Location found from Map: %f %f",location.latitude,location.longitude);
}

@end
