//
//  Coord.h
//  Location2
//
//  Created by Tommy Brown on 4/15/16.
//  Copyright © 2016 guang zhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Coord : NSObject

@property (nonatomic) float latitude;
@property (nonatomic) float longitude;

@end
