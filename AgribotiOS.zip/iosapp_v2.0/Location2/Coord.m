//
//  Coord.m
//  Location2
//
//  Created by Tommy Brown on 4/15/16.
//  Copyright © 2016 guang zhou. All rights reserved.
//

#import "Coord.h"

@implementation Coord

@end
