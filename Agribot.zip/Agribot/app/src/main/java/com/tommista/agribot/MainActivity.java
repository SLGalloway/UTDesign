package com.tommista.agribot;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import timber.log.Timber;

public class MainActivity extends AppCompatActivity implements ConnectionCallbacks,
    GoogleApiClient.OnConnectionFailedListener, SensorEventListener, OnMapReadyCallback,
    GoogleMap.OnMapClickListener{

  public ComManager comManager;
  public GoogleApiClient googleApiClient;
  public SensorManager sensorManager;

  public Button reverseButton;
  public Button enableButton;
  public SeekBar verticalSlider;
  public SeekBar horizontalSlider;
  public GoogleMap googleMap;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    Timber.plant(new Timber.DebugTree());
    comManager = ComManager.getInstance();
    comManager.context = this;

    SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
        .findFragmentById(R.id.map);
    mapFragment.getMapAsync(this);

    sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

    if(googleApiClient == null){
      googleApiClient = new GoogleApiClient.Builder(this)
          .addConnectionCallbacks(this)
          .addOnConnectionFailedListener(this)
          .addApi(LocationServices.API)
          .build();
      googleApiClient.connect();
    }

    reverseButton = (Button) findViewById(R.id.reverse_button);
    reverseButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_dark));
    reverseButton.setTag(0);
    enableButton = (Button) findViewById(R.id.enable_button);
    enableButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_dark));
    enableButton.setTag(0);

    verticalSlider = (SeekBar) findViewById(R.id.vertical_slider);
    verticalSlider.setMax(200);
    verticalSlider.setProgress(100);
    horizontalSlider = (SeekBar) findViewById(R.id.horizontal_slider);
    horizontalSlider.setMax(200);
    horizontalSlider.setProgress(100);

    verticalSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
      @Override public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        int value = i - 100;
        comManager.data.power = value;
      }

      @Override public void onStartTrackingTouch(SeekBar seekBar) {

      }

      @Override public void onStopTrackingTouch(SeekBar seekBar) {
        verticalSlider.setProgress(100);
      }
    });

    horizontalSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
      @Override public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        int value = i - 100;
        comManager.data.turn = value;
      }

      @Override public void onStartTrackingTouch(SeekBar seekBar) {

      }

      @Override public void onStopTrackingTouch(SeekBar seekBar) {
        horizontalSlider.setProgress(100);
      }
    });

    enableButton.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View view) {
        Timber.e("Swapping enable");
        if(((Integer) enableButton.getTag()) == 0){
          enableButton.setTag(1);
          enableButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
          comManager.data.enable = 1;
        }else{
          enableButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_dark));
          enableButton.setTag(0);
          comManager.data.enable = 0;
        }
      }
    });

    reverseButton.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View view) {
        Timber.e("Swapping reverse signal");
        if(comManager.data.reverse == 0){
          reverseButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
          reverseButton.setTag(1);
          comManager.data.reverse = 1;
        }else{
          reverseButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_dark));
          reverseButton.setTag(0);
          comManager.data.reverse = 0;
        }
      }
    });
  }

  @Override protected void onResume() {
    super.onResume();
    //sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_FASTEST);
    //sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_FASTEST);
    sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION), SensorManager.SENSOR_DELAY_FASTEST);
  }

  @Override protected void onPause() {
    super.onPause();
    comManager.timer.cancel();
    if(googleApiClient.isConnected()){
      googleApiClient.disconnect();
    }
    sensorManager.unregisterListener(this);
  }

  @Override public boolean onCreateOptionsMenu(Menu menu) {
    // Inflate the menu; this adds items to the action bar if it is present.
    getMenuInflater().inflate(R.menu.menu_main, menu);
    return true;
  }

  @Override public boolean onOptionsItemSelected(MenuItem item) {
    // Handle action bar item clicks here. The action bar will
    // automatically handle clicks on the Home/Up button, so long
    // as you specify a parent activity in AndroidManifest.xml.
    int id = item.getItemId();

    //noinspection SimplifiableIfStatement
    if (id == R.id.action_settings) {
      return true;
    }

    return super.onOptionsItemSelected(item);
  }

  @Override public void onConnected(Bundle bundle) {
    comManager.apiClient = googleApiClient;
  }

  @Override public void onConnectionSuspended(int i) {

  }

  @Override public void onConnectionFailed(ConnectionResult connectionResult) {

  }

  // Idk if this shit works, got it from: http://www.codingforandroid.com/2011/01/using-orientation-sensors-simple.html
  @Override public void onSensorChanged(SensorEvent sensorEvent) {
    comManager.data.heading = sensorEvent.values[0];
  }

  @Override public void onAccuracyChanged(Sensor sensor, int i) {

  }

  @Override public void onMapReady(GoogleMap googleMap) {
    Timber.e("map ready yo");
    this.googleMap = googleMap;
    comManager.googleMap = googleMap;
    googleMap.setOnMapClickListener(this);
  }

  @Override public void onMapClick(LatLng latLng) {
    Timber.e("New Waypoint lat: %f lon: %f", latLng.latitude, latLng.longitude);
    comManager.data.addWaypoint(latLng.latitude, latLng.longitude);
    comManager.data.gpsNav = 1;

    MarkerOptions deviceMarkerOptions=  new MarkerOptions().position(latLng);
    googleMap.addMarker(deviceMarkerOptions);
  }
}
