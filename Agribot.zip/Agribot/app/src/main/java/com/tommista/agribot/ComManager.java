package com.tommista.agribot;

import android.animation.ObjectAnimator;
import android.animation.TypeEvaluator;
import android.content.Context;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;
import android.util.Property;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Timer;
import java.util.TimerTask;
import timber.log.Timber;

/**
 * Created by tbrown on 5/3/16.
 */
public class ComManager {

  private static ComManager instance;
  private Socket socket;
  private OutputStream writer;
  private InputStream reader;
  public Timer timer;
  private Gson gson;
  private Marker deviceMarker;

  public GoogleApiClient apiClient;
  public TransmissionData data;
  public Context context;
  public GoogleMap googleMap;

  public static ComManager getInstance() {
    if (instance == null) {
      instance = new ComManager();
    }
    return instance;
  }

  private ComManager() {
    data = new TransmissionData();
    gson = new Gson();
    timer = new Timer("TimerThing");
    timer.scheduleAtFixedRate(new TimerTask() {
      @Override public void run() {
        Handler mainHandler = new Handler(context.getMainLooper());

        Runnable myRunnable = new Runnable() {
          @Override
          public void run() {
            Timber.i("Timer triggered");
            ComManager.this.timerTriggered();
          }
        };
        mainHandler.post(myRunnable);
      }
    }, 1000, 1000);

    // Shits dumb and needs to die
    new AsyncTask<Void, Void, Void>() {
      @Override protected Void doInBackground(Void... voids) {
        try {
          socket = new Socket("192.168.1.1", 80);
          writer = socket.getOutputStream();
          reader = socket.getInputStream();
        } catch (IOException e) {
          e.printStackTrace();
        }
        return null;
      }
    }.execute(null, null);
  }

  private void timerTriggered() {

    if (apiClient != null && apiClient.isConnected()) {
      // Ignore warning, tis dumb
      Location location = LocationServices.FusedLocationApi.getLastLocation(apiClient);
      if(location != null){
        data.latitude = (float) location.getLatitude();
        data.longitude = (float) location.getLongitude();

        if(googleMap != null){
          this.updateMap(location);
        }
      }
    }

    String jsonStr = gson.toJson(data, TransmissionData.class);
    byte[] byteArray = jsonStr.getBytes();
    if(writer != null){
      try {
        writer.write(byteArray);
      } catch (IOException e) {
        e.printStackTrace();
      }
    }else{
      Log.e(this.getClass().getSimpleName(), "Would be writing: " + jsonStr);
    }
    data.gpsNav = 0;
  }

  private void updateMap(Location location) {
    LatLng newLatLng = new LatLng(location.getLatitude(), location.getLongitude());
    if(deviceMarker == null){
      MarkerOptions deviceMarkerOptions=  new MarkerOptions()
          .position(newLatLng)
          .title("You");
      deviceMarker = googleMap.addMarker(deviceMarkerOptions);
    }else{
      deviceMarker.setPosition(newLatLng);
      //animateMarker(deviceMarker, newLatLng);
    }

    googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(newLatLng, 17.0f));

    // Prob needs to be increased
    //googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(newLatLng, 17.0f));
  }

  public void animateMarker(Marker marker, LatLng finalPosition) {
    TypeEvaluator<LatLng> typeEvaluator = new TypeEvaluator<LatLng>() {
      @Override
      public LatLng evaluate(float fraction, LatLng startValue, LatLng endValue) {
        return interpolate(fraction, startValue, endValue);
      }
    };
    Property<Marker, LatLng> property = Property.of(Marker.class, LatLng.class, "position");
    ObjectAnimator animator = ObjectAnimator.ofObject(marker, property, typeEvaluator, finalPosition);
    animator.setDuration(3500);
    animator.start();
  }

  public LatLng interpolate(float fraction, LatLng a, LatLng b) {
    double lat = (b.latitude - a.latitude) * fraction + a.latitude;
    double lngDelta = b.longitude - a.longitude;

    // Take the shortest path across the 180th meridian.
    if (Math.abs(lngDelta) > 180) {
      lngDelta -= Math.signum(lngDelta) * 360;
    }
    double lng = lngDelta * fraction + a.longitude;
    return new LatLng(lat, lng);
  }
}
