package com.tommista.agribot;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by tbrown on 5/3/16.
 */
public class TransmissionData {
  public int power;
  public int turn;
  public int enable;
  public int reverse;
  public float latitude;
  public float longitude;
  public float heading;
  public int gpsNav;
  List<double[]> waypoints;

  public TransmissionData(){
    waypoints = new ArrayList<>();
  }

  public void addWaypoint(double lat, double lon){
    double[] wp = new double[2];
    wp[0] = lat;
    wp[1] = lon;
    waypoints.add(wp);
  }
}
